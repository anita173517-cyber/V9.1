package com.harindra.tvlauncher

import android.content.Context
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object M3uRepository {

    private const val CACHE_FILE = "ultratv_m3u_cache.m3u"

    fun loadCachedChannels(context: Context): List<LiveChannel> {
        val file = File(context.filesDir, CACHE_FILE)
        if (!file.exists()) return emptyList()
        return try {
            parseM3uText(file.readText(Charsets.UTF_8))
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun saveAndParseRaw(context: Context, rawM3u: String): List<LiveChannel> {
        val file = File(context.filesDir, CACHE_FILE)
        file.writeText(rawM3u, Charsets.UTF_8)
        return parseM3uText(rawM3u)
    }

    fun fetchAndCacheFromUrl(context: Context, urlString: String): Result<List<LiveChannel>> {
        return try {
            val conn = (URL(urlString.trim()).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "UltraTVPro/6.0 (AndroidTV)")
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                return Result.failure(Exception("HTTP $code"))
            }
            val sb = StringBuilder()
            BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { reader ->
                var line: String? = reader.readLine()
                while (line != null) {
                    sb.append(line).append('\n')
                    line = reader.readLine()
                }
            }
            conn.disconnect()
            Result.success(saveAndParseRaw(context, sb.toString()))
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    fun parseM3uText(raw: String): List<LiveChannel> {
        val channels = mutableListOf<LiveChannel>()
        var pendingName = ""
        var pendingGroup = "General"
        var pendingLogo = ""
        var pendingUa = ""
        var pendingRef = ""
        var idx = 0

        for (rawLine in raw.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    pendingLogo = extractAttr(line, "tvg-logo")
                    pendingGroup = extractAttr(line, "group-title").ifBlank { "General" }
                    val commaIdx = line.lastIndexOf(',')
                    pendingName = if (commaIdx >= 0 && commaIdx + 1 < line.length) {
                        line.substring(commaIdx + 1).trim()
                    } else {
                        extractAttr(line, "tvg-name").ifBlank { "Channel ${idx + 1}" }
                    }
                }
                line.startsWith("#EXTVLCOPT:http-user-agent=", ignoreCase = true) -> {
                    pendingUa = line.substringAfter("=", "").trim()
                }
                line.startsWith("#EXTVLCOPT:http-referrer=", ignoreCase = true) -> {
                    pendingRef = line.substringAfter("=", "").trim()
                }
                line.startsWith("#") -> {}
                else -> {
                    channels.add(
                        LiveChannel(
                            id = "${idx}_${line.hashCode()}",
                            name = pendingName.ifBlank { "Live Channel ${idx + 1}" },
                            group = pendingGroup,
                            logoUrl = pendingLogo,
                            streamUrl = line,
                            userAgent = pendingUa,
                            referrer = pendingRef
                        )
                    )
                    idx++
                    pendingName = ""
                    pendingGroup = "General"
                    pendingLogo = ""
                    pendingUa = ""
                    pendingRef = ""
                }
            }
        }
        return channels
    }

    private fun extractAttr(line: String, attr: String): String {
        val key = "$attr=\""
        val start = line.indexOf(key, ignoreCase = true)
        if (start < 0) return ""
        val valStart = start + key.length
        val end = line.indexOf('"', valStart)
        if (end < 0) return ""
        return line.substring(valStart, end).trim()
    }
}
