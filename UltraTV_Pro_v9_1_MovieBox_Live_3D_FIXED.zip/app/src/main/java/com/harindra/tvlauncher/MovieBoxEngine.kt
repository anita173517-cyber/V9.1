package com.harindra.tvlauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object MovieBoxEngine {

    const val MOVIEBOX_TV_PKG = "com.community.mbox.tv"
    private val PREVIEW_URI = Uri.parse("content://android.media.tv/preview_program")

    // Exact live MovieBox TV & H5 endpoints extracted from MovieboxTv.apk!
    private val LIVE_ENDPOINTS = listOf(
        "https://api.eagllwin.com/wefeed-tv-bff/home/operating",
        "https://api.eagllwin.com/wefeed-tv-bff/search/rank",
        "https://h5.aoneroom.com/wefeed-h5-bff/web/home",
        "https://moviebox.ng/wefeed-h5-bff/web/home"
    )

    private val FALLBACK_POSTERS = intArrayOf(
        R.drawable.hero_action_4k,
        R.drawable.hero_superhero_4k,
        R.drawable.hero_thriller_4k,
        R.drawable.hero_scifi_4k,
        R.drawable.hero_fantasy_4k,
        R.drawable.hero_adventure_4k,
        R.drawable.hero_kids_4k
    )

    fun findMovieBoxPackage(installedApps: List<AppItem>): AppItem? {
        return installedApps.firstOrNull { it.packageName == MOVIEBOX_TV_PKG }
            ?: installedApps.firstOrNull {
                it.packageName == "com.community.moviebox" || it.packageName == "com.community.oneroom"
            }
            ?: installedApps.firstOrNull { app ->
                val k = (app.packageName + " " + app.label).lowercase()
                k.contains("moviebox") || k.contains("movie box") || k.contains("mbox")
            }
            ?: installedApps.firstOrNull { app ->
                val k = (app.packageName + " " + app.label).lowercase()
                k.contains("onstream") || k.contains("hdo") || k.contains("filmbox")
            }
    }

    fun fetchLiveRecommendations(context: Context): List<MovieBoxItem> {
        val liveList = mutableListOf<MovieBoxItem>()

        // 1. Query Android TV PreviewPrograms if MovieBox publishes any
        liveList.addAll(queryPreviewPrograms(context))

        // 2. Fetch LIVE daily-updated MovieBox new uploads & trending movies from MovieBox servers!
        for (endpoint in LIVE_ENDPOINTS) {
            try {
                val jsonText = httpGet(endpoint)
                if (jsonText.isNotBlank()) {
                    val parsed = parseMovieBoxJson(jsonText)
                    if (parsed.isNotEmpty()) {
                        liveList.addAll(parsed)
                        if (liveList.size >= 24) break
                    }
                }
            } catch (_: Throwable) {
                // Try next live mirror gracefully
            }
        }

        // 3. Append curated fallback items only if live list is small/offline
        return if (liveList.isNotEmpty()) {
            liveList.distinctBy { it.title.lowercase() }.take(30)
        } else {
            getCuratedMovieBoxCatalog()
        }
    }

    private fun httpGet(urlStr: String): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 5000
            readTimeout = 6000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11; Android TV) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36")
            setRequestProperty("Accept", "application/json, text/plain, */*")
            setRequestProperty("X-Client-Info", "{\"timezone\":\"Asia/Kolkata\"}")
        }
        return try {
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
            } else ""
        } finally {
            conn.disconnect()
        }
    }

    private fun parseMovieBoxJson(raw: String): List<MovieBoxItem> {
        val results = mutableListOf<MovieBoxItem>()
        try {
            val root = JSONObject(raw)
            val data = root.optJSONObject("data") ?: root
            collectSubjectsRecursive(data, results, 0)
        } catch (_: Throwable) { }
        return results
    }

    private fun collectSubjectsRecursive(node: Any?, out: MutableList<MovieBoxItem>, depth: Int) {
        if (node == null || depth > 7 || out.size >= 36) return
        when (node) {
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    collectSubjectsRecursive(node.opt(i), out, depth + 1)
                    if (out.size >= 36) break
                }
            }
            is JSONObject -> {
                val sid = node.optString("subjectId").ifBlank { node.optString("subject_id") }
                val title = node.optString("title").ifBlank { node.optString("name") }.trim()
                val coverObj = node.optJSONObject("cover") ?: node.optJSONObject("image")
                val coverUrl = coverObj?.optString("url")?.trim().orEmpty()
                    .ifBlank { node.optString("coverUrl").trim() }
                    .ifBlank { node.optString("poster").trim() }

                if (sid.isNotBlank() && title.length >= 2 && (coverUrl.startsWith("http") || node.has("genre") || node.has("subjectType"))) {
                    val genre = node.optString("genre").replace(",", " • ").ifBlank { "MovieBox Live" }
                    val ratingVal = node.optString("imdbRatingValue").ifBlank { node.optString("rating") }
                    val ratingBadge = if (ratingVal.isNotBlank() && ratingVal != "0" && ratingVal != "0.0") {
                        "★ $ratingVal • HD"
                    } else {
                        "🔥 NEW • HD"
                    }
                    val subType = node.optInt("subjectType", 1)
                    val cat = if (subType == 2) "Series" else "Movies"
                    val detailPath = node.optString("detailPath").trim()
                    val fallbackRes = FALLBACK_POSTERS[out.size % FALLBACK_POSTERS.size]

                    out.add(
                        MovieBoxItem(
                            id = "mb_live_$sid",
                            title = title,
                            meta = genre,
                            rating = ratingBadge,
                            category = cat,
                            posterResId = fallbackRes,
                            posterUrl = coverUrl,
                            subjectId = sid,
                            detailPath = detailPath
                        )
                    )
                    return
                }

                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = node.opt(k)
                    if (v is JSONObject || v is JSONArray) {
                        collectSubjectsRecursive(v, out, depth + 1)
                    }
                }
            }
        }
    }

    fun getCuratedMovieBoxCatalog(): List<MovieBoxItem> = listOf(
        MovieBoxItem("mb_1", "Jawan (Extended Cut)", "Action Thriller • Hindi / Dual Audio", "★ 8.7 • 4K", "Movies", R.drawable.hero_action_4k, trailerVideoId = "COv52Qyctws"),
        MovieBoxItem("mb_2", "Kalki 2898 AD", "Sci-Fi Action • Hindi / Telugu / 4K", "★ 8.5 • 4K", "Movies", R.drawable.hero_superhero_4k, trailerVideoId = "kQDd1AhGIHk"),
        MovieBoxItem("mb_3", "Pathaan", "Spy Action • Hindi / Tamil / Telugu", "★ 8.3 • 4K", "Movies", R.drawable.hero_thriller_4k, trailerVideoId = "vqu4z34wENw"),
        MovieBoxItem("mb_4", "Avatar: The Way of Water", "Sci-Fi Fantasy • Hindi Dubbed 4K", "★ 8.8 • 4K", "Movies", R.drawable.hero_scifi_4k, trailerVideoId = "d9MyW72ELq0"),
        MovieBoxItem("mb_5", "RRR (Rise Roar Revolt)", "Epic Action Drama • Hindi 4K HDR", "★ 8.9 • 4K", "Movies", R.drawable.hero_fantasy_4k, trailerVideoId = "f_vbAtFSEc0"),
        MovieBoxItem("mb_6", "K.G.F: Chapter 2", "Crime Action • Hindi / Kannada", "★ 8.6 • 4K", "Movies", R.drawable.hero_thriller_4k, trailerVideoId = "JKa05nyUmuQ"),
        MovieBoxItem("mb_7", "Pushpa: The Rise", "Mass Action • Hindi Dubbed HD", "★ 8.4 • HD", "Movies", R.drawable.hero_adventure_4k, trailerVideoId = "pKctjlxbFDQ"),
        MovieBoxItem("mb_8", "Mirzapur — All Seasons", "Crime Web Series • Hindi 4K", "★ 8.9 • SERIES", "Series", R.drawable.hero_thriller_4k, trailerVideoId = "ZNeGF-PvRHY")
    )

    private fun queryPreviewPrograms(context: Context): List<MovieBoxItem> {
        val out = mutableListOf<MovieBoxItem>()
        try {
            val cols = arrayOf("_id", "title", "short_description", "poster_art_uri", "intent_uri", "package_name")
            context.contentResolver.query(PREVIEW_URI, cols, null, null, null)?.use { c ->
                val iTitle = c.getColumnIndex("title")
                val iDesc = c.getColumnIndex("short_description")
                val iPoster = c.getColumnIndex("poster_art_uri")
                val iIntent = c.getColumnIndex("intent_uri")
                val iPkg = c.getColumnIndex("package_name")
                while (c.moveToNext() && out.size < 10) {
                    val pkg = if (iPkg >= 0) c.getString(iPkg).orEmpty() else ""
                    if (!pkg.contains("movie", true) && !pkg.contains("mbox", true)) continue
                    val title = if (iTitle >= 0) c.getString(iTitle).orEmpty() else ""
                    if (title.isBlank()) continue
                    out.add(
                        MovieBoxItem(
                            id = "mb_prov_${title.hashCode()}",
                            title = title,
                            meta = (if (iDesc >= 0) c.getString(iDesc).orEmpty() else "").ifBlank { "MovieBox Live" },
                            rating = "★ LIVE • HD",
                            category = "Movies",
                            posterResId = R.drawable.hero_superhero_4k,
                            posterUrl = if (iPoster >= 0) c.getString(iPoster).orEmpty() else "",
                            deepLinkUri = if (iIntent >= 0) c.getString(iIntent).orEmpty() else ""
                        )
                    )
                }
            }
        } catch (_: Throwable) { }
        return out
    }

    /**
     * Opens the EXACT movie directly inside MovieboxTv.apk (com.community.mbox.tv)
     * using its real verified DeepLinkHandler URIs (oneroom:// & h5.aoneroom.com)!
     */
    fun openInMovieBox(context: Context, prefs: PrefsManager, item: MovieBoxItem, installedApps: List<AppItem>) {
        prefs.recordMovieBoxWatch(item)

        val mbApp = findMovieBoxPackage(installedApps)
        val targetPkg = mbApp?.packageName ?: MOVIEBOX_TV_PKG

        // 1. Exact deepLinkUri from Android TV provider
        if (item.deepLinkUri.isNotBlank()) {
            try {
                val i = Intent.parseUri(item.deepLinkUri, Intent.URI_INTENT_SCHEME).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(i)
                return
            } catch (_: Throwable) { }
        }

        // 2. Exact MovieboxTv.apk DeepLinkHandler URI with real subjectId -> jumps straight into DetailPlayerActivity!
        if (item.subjectId.isNotBlank() && isInstalled(context, targetPkg)) {
            val slug = item.detailPath.ifBlank { "movie" }
            val deepLinkCandidates = listOf(
                "oneroom://com.community.oneroom/movie/detail?id=${item.subjectId}&subject_id=${item.subjectId}&subjectId=${item.subjectId}",
                "https://h5.aoneroom.com/detail/$slug?id=${item.subjectId}&subject_id=${item.subjectId}",
                "https://v.aoneroom.com/movie/detail?id=${item.subjectId}"
            )
            for (uriStr in deepLinkCandidates) {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr)).apply {
                        setPackage(targetPkg)
                        putExtra("subjectId", item.subjectId)
                        putExtra("subject_id", item.subjectId)
                        putExtra("id", item.subjectId)
                        putExtra("title", item.title)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    if (intent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(intent)
                        return
                    }
                } catch (_: Throwable) { }
            }
        }

        // 3. Direct Search Deep-Link into MovieBox for title-based items (opens search for that movie!)
        if (isInstalled(context, targetPkg)) {
            try {
                val encoded = Uri.encode(item.title)
                val searchUri = Uri.parse("oneroom://com.community.oneroom/tv/search?keyword=$encoded&query=$encoded")
                val searchIntent = Intent(Intent.ACTION_VIEW, searchUri).apply {
                    setPackage(targetPkg)
                    putExtra("keyword", item.title)
                    putExtra("query", item.title)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (searchIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(searchIntent)
                    return
                }
            } catch (_: Throwable) { }

            // Fallback: Launch MovieBox TV app cleanly
            val launch = context.packageManager.getLeanbackLaunchIntentForPackage(targetPkg)
                ?: context.packageManager.getLaunchIntentForPackage(targetPkg)
            if (launch != null) {
                launch.putExtra("subjectId", item.subjectId)
                launch.putExtra("subject_id", item.subjectId)
                launch.putExtra("keyword", item.title)
                launch.putExtra("query", item.title)
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                prefs.recordRecentPackage(targetPkg)
                try {
                    context.startActivity(launch)
                    return
                } catch (_: Throwable) { }
            }
        }

        // 4. Fallback if MovieBox is not installed
        if (item.trailerVideoId.isNotBlank()) {
            YouTubeRepository.openYouTubeVideo(context, prefs, YouTubeVideo(item.trailerVideoId, item.title, "MovieBox"))
        } else {
            Toast.makeText(context, "MovieBox TV app not installed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isInstalled(context: Context, pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Throwable) { false }
    }
}
